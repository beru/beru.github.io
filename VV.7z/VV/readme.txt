You can view two image files side by side with this application.

The program is built with VS2022 and you need Microsoft Visual C++ Runtime Library installed on your PC.
Windows Imaging Component (WIC) is used to read image files.
This program also supports viewing video files when the following ffmpeg dll files can be loaded.
- avcodec-62.dll
- avformat-62.dll
- avutil-60.dll
- avdevice-62.dll
- swscale-9.dll

If you don't have the dependency libraries on your PC, please refer to the following.
https://aka.ms/vs/17/release/vc_redist.x64.exe
https://github.com/BtbN/FFmpeg-Builds/releases
